const fs = require('fs')
const path = require('path')
const cfg = require('./config')
const { getJSON, download } = require('./download')

const MODRINTH = 'https://api.modrinth.com/v2'
const CURSE_PROXY = 'https://api.curse.tools/v1'
const CURSE_OFFICIAL = 'https://api.curseforge.com/v1'

const CURSE_LOADERS = { vanilla: 0, forge: 1, fabric: 4, quilt: 5, neoforge: 6 }

function curseKey() {
  return (cfg.load().settings.curseforgeKey || '').trim()
}

function curseBase() {
  return curseKey() ? CURSE_OFFICIAL : CURSE_PROXY
}

async function curseRequest(path, qs) {
  const key = curseKey()
  const headers = key ? { 'x-api-key': key } : {}
  return getJSON(`${curseBase()}/${path}?${qs.join('&')}`, { headers })
}

async function searchModrinth({ query, version, loader, limit = 20, page = 1 }) {
  const facets = ['["project_type:mod"]']
  if (version) facets.push(`["versions:${version}"]`)
  if (loader && loader !== 'vanilla') facets.push(`["categories:${loader}"]`)
  const offset = Math.max(0, (page - 1) * limit)
  const url = `${MODRINTH}/search?limit=${limit}&offset=${offset}&query=${encodeURIComponent(query || '')}&facets=${encodeURIComponent('[' + facets.join(',') + ']')}`
  const data = await getJSON(url)
  return {
    source: 'modrinth',
    page,
    total: data.total_hits || 0,
    hasMore: page * limit < (data.total_hits || 0),
    items: (data.hits || []).map((h) => ({
      id: h.project_id,
      slug: h.slug,
      title: h.title,
      description: h.description || '',
      icon: h.icon_url || '',
      downloads: h.downloads || 0,
      follows: h.follows || 0,
      loaders: (h.categories || []).filter((c) => ['fabric', 'forge', 'quilt', 'neoforge'].includes(c)),
      author: h.author || '',
      source: 'modrinth'
    }))
  }
}

async function modrinthVersions(projectId, { version, loader }) {
  const qs = []
  if (version) qs.push(`game_versions=${encodeURIComponent(JSON.stringify([version]))}`)
  if (loader && loader !== 'vanilla') qs.push(`loaders=${encodeURIComponent(JSON.stringify([loader]))}`)
  const url = `${MODRINTH}/project/${encodeURIComponent(projectId)}/version` + (qs.length ? '?' + qs.join('&') : '')
  const list = await getJSON(url)
  return (list || [])
    .sort((a, b) => new Date(b.date_published) - new Date(a.date_published))
    .map((v) => {
      const f = (v.files || []).find((x) => x.primary) || (v.files || [])[0] || null
      return {
        id: v.id,
        name: v.name,
        version_number: v.version_number,
        game_versions: v.game_versions || [],
        loaders: v.loaders || [],
        url: f ? f.url : '',
        filename: f ? f.filename : '',
        size: f ? f.size : 0,
        date: v.date_published,
        dependencies: v.dependencies || []
      }
    })
}

async function searchCurse({ query, version, loader, limit = 20, page = 1 }) {
  const qs = ['gameId=432', 'classId=6', `pageSize=${limit}`, `index=${Math.max(0, page - 1)}`, 'sortField=6', 'sortOrder=desc']
  if (version) qs.push(`gameVersion=${encodeURIComponent(version)}`)
  const lt = CURSE_LOADERS[loader]
  if (lt) qs.push(`modLoaderType=${lt}`)
  if (query) qs.push(`searchFilter=${encodeURIComponent(query)}`)
  const data = await curseRequest('mods/search', qs)
  const total = data.pagination ? data.pagination.totalCount : (data.data || []).length
  return {
    source: 'curseforge',
    page,
    total,
    hasMore: page * limit < total,
    items: (data.data || []).map((m) => ({
      id: String(m.id),
      slug: m.slug,
      title: m.name,
      description: m.summary || '',
      icon: (m.logo && m.logo.url) || '',
      downloads: m.downloadCount || m.totalDownloads || 0,
      follows: 0,
      loaders: [],
      author: '',
      source: 'curseforge'
    }))
  }
}

async function curseVersions(modId, { version, loader }) {
  const qs = ['pageSize=50']
  if (version) qs.push(`gameVersion=${encodeURIComponent(version)}`)
  const lt = CURSE_LOADERS[loader]
  if (lt) qs.push(`modLoaderType=${lt}`)
  const data = await curseRequest(`mods/${encodeURIComponent(modId)}/files`, qs)
  return (data.data || [])
    .sort((a, b) => new Date(b.fileDate) - new Date(a.fileDate))
    .map((f) => ({
      id: String(f.id),
      fileId: String(f.id),
      name: f.displayName || f.fileName,
      version_number: f.fileName,
      game_versions: f.gameVersions || [],
      loaders: [],
      url: f.downloadUrl || '',
      filename: f.fileName,
      size: f.fileLength || 0,
      date: f.fileDate
    }))
}

async function search(opts) {
  let res
  if (opts.source === 'all') {
    const pool = Math.max(opts.limit || 20, 50)
    const [a, b] = await Promise.all([
      searchModrinth({ ...opts, limit: pool, page: 1 }),
      searchCurse({ ...opts, limit: pool, page: 1 })
    ])
    const seen = new Set()
    const all = []
    for (const it of [...a.items, ...b.items]) {
      const k = String(it.slug || it.id || '').toLowerCase()
      if (!k || seen.has(k)) continue
      seen.add(k)
      all.push(it)
    }
    all.sort((x, y) => (y.downloads || 0) - (x.downloads || 0))
    const page = Math.max(1, opts.page || 1)
    const limit = Math.max(1, opts.limit || 20)
    const start = (page - 1) * limit
    res = { source: 'all', page, total: all.length, hasMore: start + limit < all.length, items: all.slice(start, start + limit) }
  } else {
    res = opts.source === 'curseforge' ? await searchCurse(opts) : await searchModrinth(opts)
  }
  try {
    const instanceId = opts.instance || opts.instanceId || ''
    const meta = loadMeta(instanceId)
    const files = listInstalled(instanceId).map((f) => f.file.toLowerCase())
    for (const item of res.items) {
      const key = item.id || item.slug || ''
      item.installed = meta.some((m) => (m.projectId && m.projectId === key) || (item.slug && m.slug === item.slug)) ||
        files.some((f) => item.slug && f.includes(item.slug.toLowerCase()))
    }
  } catch (e) {}
  return res
}

async function versions(opts) {
  if (opts.source === 'curseforge') return curseVersions(opts.id, opts)
  return modrinthVersions(opts.id, opts)
}

function modsDir(instanceId) {
  const dir = path.join(cfg.paths().game, instanceId, 'mods')
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

function safeFileName(name) {
  const base = path.basename(String(name || 'mod.jar')).replace(/[\\/:*?"<>|]/g, '_')
  return base.toLowerCase().endsWith('.jar') ? base : base + '.jar'
}

function installedMetaFile(instanceId) {
  return path.join(modsDir(instanceId), 'installed-mods.json')
}

function loadMeta(instanceId) {
  try {
    return JSON.parse(fs.readFileSync(installedMetaFile(instanceId), 'utf8')) || []
  } catch (e) {
    return []
  }
}

function saveMeta(instanceId, arr) {
  try {
    fs.writeFileSync(installedMetaFile(instanceId), JSON.stringify(arr, null, 2))
  } catch (e) {}
}

function metaAdd(instanceId, entries) {
  const arr = loadMeta(instanceId)
  for (const e of entries) {
    if (!arr.some((m) => m.file === e.file)) arr.push(e)
  }
  saveMeta(instanceId, arr)
}

function metaRemove(instanceId, fileName) {
  saveMeta(instanceId, loadMeta(instanceId).filter((m) => m.file !== fileName))
}

async function modrinthDepsFor(projectId, versionId) {
  const v = await getJSON(`${MODRINTH}/project/${encodeURIComponent(projectId)}/version/${encodeURIComponent(versionId)}`)
  return (v.dependencies || []).filter((d) => d.dependency_type === 'required' && d.project_id)
}

async function curseDepsFor(modId, fileId) {
  const data = await curseRequest(`mods/${encodeURIComponent(modId)}/files/${encodeURIComponent(fileId)}`)
  return ((data.data && data.data.dependencies) || []).filter((d) => d.relationType === 1)
}

async function downloadDeps(opts, v, installed, seen, count, onVersion) {
  const curse = (opts.source || 'modrinth') === 'curseforge'
  let deps = []
  if (curse) {
    if (v.fileId) deps = await curseDepsFor(opts.id, v.fileId)
  } else {
    if (v.id) deps = await modrinthDepsFor(opts.id, v.id)
  }
  for (const d of deps) {
    const pid = curse ? String(d.modId) : d.project_id
    if (!pid || seen.has(pid)) continue
    seen.add(pid)
    const list = curse
      ? await curseVersions(pid, { version: opts.version, loader: opts.loader })
      : await modrinthVersions(pid, { version: opts.version, loader: opts.loader })
    const dep = (list || [])[0]
    if (!dep || !dep.url) continue
    const dest = path.join(modsDir(opts.instanceId), safeFileName(dep.filename))
    if (fs.existsSync(dest)) continue
    if (onVersion) onVersion(dep)
    await download(dep.url, dest, {})
    installed.push({
      file: path.basename(dest),
      projectId: pid,
      slug: '',
      title: dep.name || dep.version_number || '',
      source: curse ? 'curseforge' : 'modrinth',
      versionNumber: dep.version_number || '',
      dependency: true
    })
    count.n++
    await downloadDeps({ ...opts, id: pid, source: curse ? 'curseforge' : 'modrinth' }, dep, installed, seen, count, onVersion)
  }
  return count
}

async function install(opts, onVersion) {
  let v = null
  if (opts.forceUrl) {
    v = { url: opts.forceUrl, filename: opts.forceFile || 'mod.jar', name: opts.forceFile || 'mod', version_number: '', size: 0 }
    if (opts.forceVersionId) v.id = opts.forceVersionId
    if (opts.fileId) v.fileId = opts.fileId
  } else {
    const list = await versions(opts)
    v = (list || [])[0]
  }
  if (!v || !v.url) throw new Error('ما فيه إصدار متوافق مع نسختك')
  if (onVersion) onVersion(v)

  const dest = path.join(modsDir(opts.instanceId), safeFileName(v.filename))
  await download(v.url, dest, { onProgress: opts.onProgress })

  const installed = [{
    file: path.basename(dest),
    projectId: opts.id,
    slug: opts.slug || '',
    title: opts.title || v.name || '',
    source: opts.source || 'modrinth',
    versionNumber: v.version_number || '',
    dependency: false
  }]

  let dependencies = 0
  try {
    const count = await downloadDeps(opts, v, installed, new Set([opts.id]), { n: 0 }, onVersion)
    dependencies = count.n
  } catch (e) {}
  metaAdd(opts.instanceId, installed)

  return { file: path.basename(dest), name: v.name, version_number: v.version_number, size: v.size, dependencies }
}

function listInstalled(instanceId) {
  const dir = modsDir(instanceId)
  try {
    return fs.readdirSync(dir)
      .filter((f) => f.toLowerCase().endsWith('.jar'))
      .map((f) => {
        const st = fs.statSync(path.join(dir, f))
        return { file: f, size: st.size, modified: st.mtime }
      })
      .sort((a, b) => a.file.localeCompare(b.file))
  } catch (e) {
    return []
  }
}

function remove(instanceId, fileName) {
  const dest = path.join(modsDir(instanceId), path.basename(fileName))
  if (fs.existsSync(dest)) fs.unlinkSync(dest)
  metaRemove(instanceId, path.basename(fileName))
}

function openModsFolder(instanceId) {
  const dir = modsDir(instanceId)
  require('child_process').exec(process.platform === 'win32' ? `explorer "${dir}"` : `open "${dir}"`)
  return dir
}

module.exports = { search, versions, install, listInstalled, remove, openModsFolder }
